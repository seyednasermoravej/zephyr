/*
 * Copyright (c) 2024, Witekio
 *
 * SPDX-License-Identifier: Apache-2.0
 */
async function fetchUptime()
{
	try {
		const response = await fetch("/uptime");
		if (!response.ok) {
			throw new Error(`Response status: ${response.status}`);
		}

		const json = await response.json();
		const uptime = document.getElementById("uptime");
		uptime.innerHTML = "Uptime: " + json + " milliseconds"
	} catch (error) {
		console.error(error.message);
	}
}

async function postLed(state)
{
	try {
		const payload = JSON.stringify({"led_num" : 0, "led_state" : state});

		const response = await fetch("/led", {method : "POST", body : payload});
		if (!response.ok) {
			throw new Error(`Response satus: ${response.status}`);
		}
	} catch (error) {
		console.error(error.message);
	}
}

function setNetStat(json_data, stat_name)
{
	document.getElementById(stat_name).innerHTML = json_data[stat_name];
}

window.addEventListener("DOMContentLoaded", (ev) => {
	/* Fetch the uptime once per second */
	setInterval(fetchUptime, 1000);

    // --- Piezo Controls with Slide Bars ---
    const piezoValueSlider = document.getElementById("piezo_value"); // Main value slider
    const piezoRedSlider = document.getElementById("piezo_red");   // Red color slider
    const piezoGreenSlider = document.getElementById("piezo_green"); // Green color slider
    const piezoBlueSlider = document.getElementById("piezo_blue");  // Blue color slider

    // Event listeners for each slider
    piezoValueSlider.addEventListener("input", () => {
        const value = piezoValueSlider.value;
        postLed(true); // Assuming true means "on" - adjust as needed
    });

    piezoRedSlider.addEventListener("input", () => {
        const redValue = piezoRedSlider.value;
        postLed(true);  // Adjust as needed
    });

    piezoGreenSlider.addEventListener("input", () => {
        const greenValue = piezoGreenSlider.value;
        postLed(true); // Adjust as needed
    });

    piezoBlueSlider.addEventListener("input", () => {
        const blueValue = piezoBlueSlider.value;
        postLed(true);  // Adjust as needed
    });

	/* POST to the LED endpoint when the buttons are pressed */
	const led_on_btn = document.getElementById("led_on");
	led_on_btn.addEventListener("click", (event) => {
		console.log("led_on clicked");
		postLed(true);
	})

	const led_off_btn = document.getElementById("led_off");
	led_off_btn.addEventListener("click", (event) => {
		console.log("led_off clicked");
		postLed(false);
	})

    const piezoControl = document.getElementById("piezo");
    piezoControl.addEventListener("input", () => {
        const value = piezoControl.value;
        console.log('Pizeo Value: ${value}');
    })

	/* Setup websocket for handling network stats */
	const ws = new WebSocket("/");

	ws.onmessage = (event) => {
		const data = JSON.parse(event.data);
		setNetStat(data, "bytes_recv");
		setNetStat(data, "bytes_sent");
		setNetStat(data, "ipv6_pkt_recv");
		setNetStat(data, "ipv6_pkt_sent");
		setNetStat(data, "ipv4_pkt_recv");
		setNetStat(data, "ipv4_pkt_sent");
		setNetStat(data, "tcp_bytes_recv");
		setNetStat(data, "tcp_bytes_sent");
	}
})
